<?php
// Text
$_['text_subject']  = '%s - Password reset request';
$_['text_greeting'] = 'A new password was requested for %s administration.';
$_['text_change']   = 'To reset your password click on the link below:';
$_['text_ip']       = 'The IP used to make this request was:';